import { HeaderBarButtonItem } from 'react-native-screens/types';
export declare const prepareHeaderBarButtonItems: (barButtonItems: HeaderBarButtonItem[], side: "left" | "right") => (import("react-native-screens/types").HeaderBarButtonItemSpacing | {
    buttonId: string;
    imageSource: import("react-native").ImageResolvedAssetSource | undefined;
    sfSymbolName: string | undefined;
    labelStyle: {
        color: import("react-native").ProcessedColorValue | null | undefined;
        fontFamily?: string;
        fontSize?: number;
        fontWeight?: string;
    } | undefined;
    tintColor: import("react-native").ProcessedColorValue | null | undefined;
    badge: {
        style: {
            color: import("react-native").ProcessedColorValue | null | undefined;
            backgroundColor: import("react-native").ProcessedColorValue | null | undefined;
            fontFamily?: string;
            fontSize?: number;
            fontWeight?: string;
        };
        value: string;
    } | undefined;
    onPress: () => void;
    selected?: boolean;
    changesSelectionAsPrimaryAction?: boolean;
    index?: number;
    label?: string;
    icon?: import("react-native-screens/types").PlatformIconIOS;
    variant?: "plain" | "done" | "prominent";
    disabled?: boolean;
    width?: number;
    hidesSharedBackground?: boolean;
    sharesBackground?: boolean;
    identifier?: string;
    accessibilityLabel?: string;
    accessibilityHint?: string;
} | {
    buttonId: string;
    imageSource: import("react-native").ImageResolvedAssetSource | undefined;
    sfSymbolName: string | undefined;
    labelStyle: {
        color: import("react-native").ProcessedColorValue | null | undefined;
        fontFamily?: string;
        fontSize?: number;
        fontWeight?: string;
    } | undefined;
    tintColor: import("react-native").ProcessedColorValue | null | undefined;
    badge: {
        style: {
            color: import("react-native").ProcessedColorValue | null | undefined;
            backgroundColor: import("react-native").ProcessedColorValue | null | undefined;
            fontFamily?: string;
            fontSize?: number;
            fontWeight?: string;
        };
        value: string;
    } | undefined;
    menu: {
        label?: string;
        items: (import("react-native-screens/types").HeaderBarButtonItemMenuAction | import("react-native-screens/types").HeaderBarButtonItemSubmenu)[];
    };
    index?: number;
    label?: string;
    icon?: import("react-native-screens/types").PlatformIconIOS;
    variant?: "plain" | "done" | "prominent";
    disabled?: boolean;
    width?: number;
    hidesSharedBackground?: boolean;
    sharesBackground?: boolean;
    identifier?: string;
    accessibilityLabel?: string;
    accessibilityHint?: string;
} | {
    menu: {
        label?: string;
        items: (import("react-native-screens/types").HeaderBarButtonItemMenuAction | import("react-native-screens/types").HeaderBarButtonItemSubmenu)[];
    };
    imageSource: import("react-native").ImageResolvedAssetSource | undefined;
    sfSymbolName: string | undefined;
    labelStyle: {
        color: import("react-native").ProcessedColorValue | null | undefined;
        fontFamily?: string;
        fontSize?: number;
        fontWeight?: string;
    } | undefined;
    tintColor: import("react-native").ProcessedColorValue | null | undefined;
    badge: {
        style: {
            color: import("react-native").ProcessedColorValue | null | undefined;
            backgroundColor: import("react-native").ProcessedColorValue | null | undefined;
            fontFamily?: string;
            fontSize?: number;
            fontWeight?: string;
        };
        value: string;
    } | undefined;
    onPress: () => void;
    selected?: boolean;
    changesSelectionAsPrimaryAction?: boolean;
    index?: number;
    label?: string;
    icon?: import("react-native-screens/types").PlatformIconIOS;
    variant?: "plain" | "done" | "prominent";
    disabled?: boolean;
    width?: number;
    hidesSharedBackground?: boolean;
    sharesBackground?: boolean;
    identifier?: string;
    accessibilityLabel?: string;
    accessibilityHint?: string;
} | {
    menu: {
        label?: string;
        items: (import("react-native-screens/types").HeaderBarButtonItemMenuAction | import("react-native-screens/types").HeaderBarButtonItemSubmenu)[];
    };
    imageSource: import("react-native").ImageResolvedAssetSource | undefined;
    sfSymbolName: string | undefined;
    labelStyle: {
        color: import("react-native").ProcessedColorValue | null | undefined;
        fontFamily?: string;
        fontSize?: number;
        fontWeight?: string;
    } | undefined;
    tintColor: import("react-native").ProcessedColorValue | null | undefined;
    badge: {
        style: {
            color: import("react-native").ProcessedColorValue | null | undefined;
            backgroundColor: import("react-native").ProcessedColorValue | null | undefined;
            fontFamily?: string;
            fontSize?: number;
            fontWeight?: string;
        };
        value: string;
    } | undefined;
    index?: number;
    label?: string;
    icon?: import("react-native-screens/types").PlatformIconIOS;
    variant?: "plain" | "done" | "prominent";
    disabled?: boolean;
    width?: number;
    hidesSharedBackground?: boolean;
    sharesBackground?: boolean;
    identifier?: string;
    accessibilityLabel?: string;
    accessibilityHint?: string;
} | null)[];
//# sourceMappingURL=prepareHeaderBarButtonItems.d.ts.map